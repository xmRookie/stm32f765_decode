#ifdef MP2_ENC

#include "system.h"

#include "codec.h"

#include "adac_buffer.h"

#include "SDK-ezkitutilities.h"

#include "usb_fileio.h"

#include "usb_audio_6ch_services.h"



#include "libavutil/internal.h"

#include "avcodec.h"

#include "mpegaudio.h"

#include <cplbtab.h>



//section("L1_data_a")

int testCount = 0;

//section("L1_data_a")

int updateFlag = 1;

#ifdef _LOW_DELAY

//section("L1_data_a")

int updateFlag1 = 0;

   extern int testCount0, testCount1;

#endif



#include <lwip/sockets.h>

#include <stdio.h>               // stdio header

#include <string.h>              // string header

#include <stdlib.h>

#include <math.h>

#include <cycle_count.h>         // for basic cycle counting

#ifdef _TCPIP                              // add socket/tcpip support for packet delivery

#include <lwip/sockets.h>

#include <lwip/inet.h>

#endif

#if defined(_DBG_MP2_BS)

//section("dbg_mp2_buffer") /*static*/ int dbg_mp2_buffer[345600];   // aligned buffer & divisible into mp2 audio frame, liyenho

#endif



extern int MPA_encode_init(AVCodecContext *avctx);

extern int MPA_encode_frame(AVCodecContext *avctx,

                            unsigned char *frame, int buf_size, void *data);

extern int MPA_encode_close(AVCodecContext *avctx);



/******************************************************************************

**          #defines

******************************************************************************/

#include "UART_ctrl.h"

#include "MP2_demo.h"

#define FILE_NAME_LEN 48

#define PATH_NAME_LEN 96

#define NUM_INPUT_PCM_CHANNELS   (2)



/******************************************************************************

**          Typedefs/Enumerations

******************************************************************************/

typedef unsigned char   Byte;



/******************************************************************************

**          Local variables

******************************************************************************/



//section("adi_slow_noprio_rw") static

char current_output_file_name[FILE_NAME_LEN];

//section("adi_slow_noprio_rw") static

char current_path[PATH_NAME_LEN];

char enc_type[10];

char enc_format[10];



#pragma align 4   // resided at L1 bank A for speed, liyenho

////section("L1_data_a")

short enc_input_buffer[MPA_FRAME_SIZE*NUM_INPUT_PCM_CHANNELS];



// encoder variables

adi_aenc_config_t config_param;   // to be access from MP2_ctrl.c in part, liyenho

#ifdef _UART_CONFIG

extern int mp2_request_reconfig; // defined from MP2_ctrl.c, liyenho

#endif

// resided at L1 bank A for speed, liyenho

////section("L1_data_a")

static unsigned int bitstream_buffer[MPA_MAX_CODED_FRAME_SIZE/(sizeof(int))];

// used to interlace bit stream buffer for transport, liyenho

////section("L3_MEM")

static int bit_stream_pattern[FIFO_BUFFER_SIZE*NUM_FIFO_BUFFERS];

const int bitstream_buffer_size = MPA_MAX_CODED_FRAME_SIZE;



#pragma align 4   // one copy for rx, the other for tx, liyenho

////section("adac_buffers")

static int rx_fifo_buffer[FIFO_BUFFER_SIZE*NUM_FIFO_BUFFERS];

////section("dac_buffers")

static int tx_fifo_buffer[1024*1024/sizeof(int)/*FIFO_BUFFER_SIZE*NUM_FIFO_BUFFERS*/];



extern volatile u32 iADCdata1[(ADC_CHANNEL_NUMBER * ADAC_BUFFER_SIZE)];

extern volatile u32 iADCdata2[(ADC_CHANNEL_NUMBER * ADAC_BUFFER_SIZE)];

extern volatile u32 iDACdata1[(DAC_CHANNEL_NUMBER * ADAC_BUFFER_SIZE)];

extern volatile u32 iDACdata2[(DAC_CHANNEL_NUMBER * ADAC_BUFFER_SIZE)];

#ifdef YH_DMA_TX_DIRECT

  extern  u32 dma_tx_wr_select;

#endif



/******************************************************************************

**          Local function declaration

******************************************************************************/

int get_encode_param(FILE *fileptr);

void print_encode_param(void);





//YH test code --------------------------------------------------

#ifdef YH_I2SCNTCHECK

void memchk(int * block);

static unsigned short val_prev=0, val_curr;

static unsigned int error_cnt2=0, ivv;

static int memchkarray[ADAC_BUFFER_SIZE*2];

unsigned int pktcnt;

#endif

#ifdef YH_TIMECHECK

static unsigned int time_start_enc, time_end_enc;

unsigned int time_fifo_wr, time_txdma;

#endif

char dma_test_val;

//---------------------------------------------------------------







/******************************************************************************

**          Function Definitions

******************************************************************************/

/*

**

** Function:            do_MP2_recorder

**

** Description:         encoder main function

**

** Arguments:        none

**

** Outputs:             none

**

** Return value:        encoder status

**

*/

//section("adi_slow_noprio_code")

int do_MP2_recorder()

{

   FILE *fp_mp2_dir = NULL;         // file pointer to list file



   int next_file;

   char key;



   int return_code = CODEC_SUCCESS;

    ezInitButton(0);



   // Open MP2 list file

#ifdef USE_USBIO

   strcpy(current_path, ROOT_DIR);

   fp_mp2_dir = fopen( strcat(strcat(current_path, SPEC_DIR), "mp2_list_enc.txt"), "r" );



   if (fp_mp2_dir == NULL)

   {

      fprintf( fperr, "Error: could not read directory file\n" );

      return CODEC_FILE_ERROR;

   }



   // start encoding

   printf("Reading list of MP2 files from %s\n\n", "mp2_list_enc.txt");

#endif

   // get enc parameters from file

   next_file = get_encode_param(fp_mp2_dir);

   while(next_file != EOF)

   {

#ifdef USE_USBIO

      printf("\nOutput file:  %s\n", current_output_file_name);



      // build the next input file name in tempstring

      strcpy(current_path, ROOT_DIR);

      strcat(strcat(current_path, "Media\\MP2_Recorder\\"), current_output_file_name);

#endif

      print_encode_param();

      // Decode

      MP2_Encode(current_path);



      // get enc parameters from file

      next_file = get_encode_param(fp_mp2_dir);



      if(!next_file) next_file = EOF;

#ifdef USE_USBIO

      fflush(stdout);

#endif

   }

#ifdef USE_USBIO

   if(!return_code)

      printf("\nReached end of list\n");



   // close the list file

   fclose( fp_mp2_dir );

#endif

   return CODEC_SUCCESS;

}



/*

**

** Function:            MP2_Encode

**

** Description:         Function that encodes AD1836 audio into an MP2 file (currently only PCM supported)

**

** Arguments:        filename

**

** Outputs:             none

**

** Return value:        MP2 encoder status

**

*/

//section("adi_slow_noprio_code")

int MP2_Encode(char *filename)

{

   FILE *fileout;

   int ch, *pFifoBuffer, *pFifoBuffer1;

#ifdef _LOW_DELAY

   static int *adcBuffPtr[2] = {(int*)iADCdata1,(int*)iADCdata2};

   static int *dacBuffPtr[2] = {(int*)iDACdata1,(int*)iDACdata2};

   int  adcBuffIdx1; // dac/adc ISR buffer indice, liyenho

#endif

    unsigned int i, j;

   int enc_nNumSamples = MPA_FRAME_SIZE;

   int result = 0;

#ifdef _DBG_MP2_BS

   char *pdbg = NULL, *pdbgEnd = NULL;   // added by liyenho

#endif

   AVCodecContext  avctx;

// not the right format for mp2 enc, not applied, liyenho

   short *enc_input_pcm_channels[NUM_INPUT_PCM_CHANNELS];



   for(ch = 0; ch<NUM_INPUT_PCM_CHANNELS; ch++)

      enc_input_pcm_channels[ch] = &enc_input_buffer[ch];

#ifdef _DBG_MP2_BS   // debugg buffer ptr management, liyenho

   pdbg = (char*) dbg_mp2_buffer;

   pdbgEnd = pdbg + sizeof(dbg_mp2_buffer);

#elif defined(USE_USBIO)

   // Open the MP2 file



   fileout = fopen(filename,"wb");



   if (fileout == NULL)

   {

      printf("unable to read input file\n");

      return CODEC_FILE_ERROR;

   }

#endif

#if defined(__ADSP_EDINBURGH__)   // BF533 supports 48kHz sampling rate only

   if ((config_param.sample_rate) != 48000)

   {

      printf("ADSP-BF533 EZKIT does NOT support %dHz sampling rate\n", config_param.sample_rate);

      printf("ADSP-BF533 EZKIT supports ONLY 48000Hz sampling rate\n");

      printf("Skip to the next file ...\n");

      fclose(fileout);

      return CODEC_ALGORITHM_ERROR;

   }



#elif (defined(__ADSP_KOOKABURRA__) || defined(__ADSP_MOAB__) || defined(__ADSP_BRAEMAR__))   // BF527 or BF 548, added BF537, liyenho

   if (((config_param.sample_rate) != 32000)&&((config_param.sample_rate) != 44100)&&((config_param.sample_rate) != 48000))

   {

#ifdef USE_USBIO

      printf("The encoder library ONLY supports 32000, 44100 or 48000Hz\n");

      printf("Skip to the next file ...\n");

      fclose(fileout);

#endif

      printf("The encoder library does NOT support %dHz sampling rate\n", config_param.sample_rate);

      return CODEC_ALGORITHM_ERROR;

   }

#endif



// result = EnableCodecDataflow(&(config_param.sample_rate)); redundant, removed by liyenho



   if (result != 0)

   {

#ifdef USE_USBIO

      printf("Unable to configure CODEC with given sampling rate\n");

      fclose(fileout);

#endif

   printf("audio drivers are dead, restart all...\n");

      ReinstallAudioDriver();

      return CODEC_ALGORITHM_ERROR;

   }



   if (!(avctx.priv_data= (void*)calloc(1,sizeof(MpegAudioContext))))

   {

      av_log(NULL,AV_LOG_ERROR,"fail to allocate MpegAudioContext struct...\n");

      return CODEC_MEMORY_ALLOCATION_ERROR;

   }



   avctx.sample_rate = config_param.sample_rate;

      avctx.channels = config_param.num_channels;

   int bitrate = config_param.avg_bitrate_bps;

   if (0>bitrate || 448000<bitrate)

      {

         av_log(NULL,AV_LOG_ERROR,"invalid bit rate assignment...\n");

         av_free(avctx.priv_data);

         return CODEC_ALGORITHM_ERROR;

      }

      avctx.bit_rate = bitrate;

   if (0>MPA_encode_init(&avctx))

   {

      av_log(NULL,AV_LOG_ERROR,"fail to call MPA_encode_init...\n");

      av_free(avctx.priv_data);

      return CODEC_ALGORITHM_ERROR;

   }

#if defined(__ADSP_EDINBURGH__)   // BF533

    printf("Press button SW4 to START recording...\n");

#endif



#if defined(__ADSP_KOOKABURRA__)  // BF527

    printf("Press button PB2 to START recording...\n");

#endif



#if defined(__ADSP_MOAB__)  // BF548

    printf("Press button PB1 to START recording...\n");

#endif



#if defined(__ADSP_BRAEMAR__)  // added by liyenho

    printf("Press button SW13 to START recording...\n");

#endif

#ifndef _NO_BUTTON

   // wait for button to pressed

   while(!ezIsButtonPushed(0));

#else // self boot

   while(0);

#endif

#if defined(__ADSP_EDINBURGH__)   // BF533

    printf("RECORDING... Press button SW4 again to STOP recording....\n");

#endif



#if defined(__ADSP_KOOKABURRA__)  // BF527

    printf("RECORDING... Press button PB2 again to STOP recording....\n");

#endif



#if defined(__ADSP_MOAB__)  // BF548

    printf("RECORDING... Press button PB1 again to STOP recording....\n");

#endif



#if defined(__ADSP_BRAEMAR__)  // added by liyenho

    printf("RECORDING... Press button SW13 again to STOP recording....\n");

#endif

   while(ezIsButtonPushed(0));



    // User routine initialization

#if defined CODEC_BF52xC1

   int pcm_data_block_length = enc_nNumSamples << 1;

#elif defined CODEC_AD1980

   int pcm_data_block_length = enc_nNumSamples << 1;

#elif defined CODEC_AD1836

   int pcm_data_block_length = enc_nNumSamples << 3;

#elif defined(CODEC_AD1854)      // added by liyenho (stereo pair only)

   int pcm_data_block_length = enc_nNumSamples << 1;

#endif   // added by liyenho

//   adi_int_SICDisable(ADI_INT_DMA4_SPORT0_TX);   // disable Tx dma getting into core event, liyenho

   usr_init(1/*tx*/, tx_fifo_buffer, FIFO_BUFFER_SIZE, 64);   // inti tx fifo buffers

#ifndef _LOW_DELAY

   usr_init(0/*rx*/, rx_fifo_buffer, FIFO_BUFFER_SIZE, NUM_FIFO_BUFFERS);  // init rx fifo buffers

#else // low delay design

   extern volatile int adcBuffIdx;

      while  (-1 == adcBuffIdx) ; // bypass uninitial stage, just in case there is not much delay to kick off enc

      adcBuffIdx1 = adcBuffIdx;

      // bypass current frame, too risky (too close to end of frame) to proceed right away, liyenho

      while  (adcBuffIdx1 == adcBuffIdx) ;

      adcBuffIdx1 = 1 ^ adcBuffIdx1;

      testCount0 = testCount-1;  // capture initial delay minus 1, liyenho

      updateFlag1 = 1;   // enable tx speed test flag, liyenho

#endif

   while(1)

   {

        // Repeat until a chunk is ready, then encoded it and write result

#ifndef _LOW_DELAY

        do

       {                      // we must use this fifo func due to blackfin Dma constraint

         pFifoBuffer = (int*)usr_getpcmblock(0/*rx*/);

        } while (pFifoBuffer == 0);

                                       #ifdef YH_TIMECHECK

                                          time_start_enc = clock();

                                       #endif

#else // low delay design

      pFifoBuffer = adcBuffPtr[adcBuffIdx1];

#endif

#if defined CODEC_BF52xC1

      for(i=0;i<pcm_data_block_length;i++)

      {

         for(j=0;j<NUM_INPUT_PCM_CHANNELS;j++)

         {

            enc_input_pcm_channels[NUM_INPUT_PCM_CHANNELS-1-j][i*NUM_INPUT_PCM_CHANNELS] = (short)pFifoBuffer[2*i+j];

         }

      }



#elif defined CODEC_AD1980

      for(i=0;i<pcm_data_block_length;i++)

      {

         for(j=0;j<NUM_INPUT_PCM_CHANNELS;j++)

         {

            enc_input_pcm_channels[NUM_INPUT_PCM_CHANNELS-1-j][i*NUM_INPUT_PCM_CHANNELS] = (short)(pFifoBuffer[2*i+j] << 12 >> 16); // AD1980 CODEC in 20-bit so >> 4 to make it 16-bit

         }

      }

#elif defined CODEC_AD1836



      // up to 8 ch mapping and 32-bit to 16-bit sample conversion

      for(i=0;i<enc_nNumSamples;i++)

      {

         for(j=0;j<NUM_INPUT_PCM_CHANNELS;j++)

         {

            enc_input_pcm_channels[j][i*NUM_INPUT_PCM_CHANNELS] = (short)(pFifoBuffer[8*i + ((j>>1) + ((j&1)<<2))]>>16); //  1L pFifoBuffer[8*i]; 2L pFifoBuffer[8*i+1];

         }

      }

#elif defined(CODEC_AD1854)   // added by liyenho for bf537 ez-kit

                                      #ifdef YH_I2SCNTCHECK

                                          memchk(pFifoBuffer); ///YH

                                      #endif

      for(i=0;i<enc_nNumSamples;i++)

      {

         for(j=0;j<NUM_INPUT_PCM_CHANNELS;j++)

         {

#ifndef _USE_24_BITS

            enc_input_pcm_channels[j][i*NUM_INPUT_PCM_CHANNELS] = (short)(pFifoBuffer[2*i+j]); // AD1871 CODEC used in 16-bit mode

#else //_USE_24_BITS

            enc_input_pcm_channels[j][i*NUM_INPUT_PCM_CHANNELS] = (short)  (((pFifoBuffer[2*i+j]>>8)));

#endif





            }

      }

         /*if ((pdbg+(enc_nNumSamples*2*2)) < pdbgEnd)

            for(i=0;i<enc_nNumSamples;i++)

               for(j=0;j<NUM_INPUT_PCM_CHANNELS;j++)

               {

                  *((short*)pdbg) = (short)(16*pFifoBuffer[2*i+j]);

                  pdbg += 2;

               }*/

#endif

#ifdef _FOR_FUN

#ifndef _LOW_DELAY

       do

       {   // added by liyenho for ping pong (dac) buffer playback audio stream @ real time

         pFifoBuffer1 = (int*)usr_getpcmbuffer(1/*tx*/,pcm_data_block_length);

       } while (pFifoBuffer1 == 0);

#endif

        for (i=0;i<pcm_data_block_length;/*i++*/i+=2)

        {   // align to msb prior to copy

#ifdef _USE_24_BITS

           *(pFifoBuffer+i) =  (((pFifoBuffer[i]<<8)>>0/*3*/)>>8); // 24 bit inp

           *(pFifoBuffer+i+1) =  (((pFifoBuffer[i+1]<<8)>>0)>>8);

#else //!_USE_24_BITS

           *(pFifoBuffer+i) =  (((pFifoBuffer[i]<<16))>>(0/*3*/))>>8; // 16 bit inp

           *(pFifoBuffer+i+1) =  (((pFifoBuffer[i+1]<<(16))))>>8;

#endif

        }

        // copy adc buffer into temp fifo mem for dac dma

#ifndef _LOW_DELAY

        i = usr_writepcmblock(1/*tx*/,pcm_data_block_length*4, (char*)pFifoBuffer);

         if (pcm_data_block_length != (i>>2)) printf("tx mem copy fails...\n");

#endif

#endif

#ifndef _LOW_DELAY

   usr_pcmblockclear(0/*rx*/);   // we must use this fifo func due to blackfin Dma constraint

#endif

   int num_output_bytes_produced;

#if 1 /*tcpip module can NOT work properly with he-aac encoder On! how about mp2? */

      // encode current frame in stereo setup, return # of bytes coded

      num_output_bytes_produced= MPA_encode_frame(&avctx,

                            (unsigned char*)bitstream_buffer,

                            bitstream_buffer_size,

                            (void*)enc_input_buffer);

   static int frames=0;

   printf("%d...\n",frames++); // remove later, liyenho

#else // for tcpip debugg, liyenho

      num_output_bytes_produced = bitstream_buffer_size;

#endif



        // Write one frame of encoded audio to file

       if (num_output_bytes_produced)

       {

#ifdef USE_USBIO

         if (usbio_fwrite((unsigned char*)bitstream_buffer, num_output_bytes_produced, fileout)!=num_output_bytes_produced)

           {

               printf("Error writing bitstream data to file\n");

               return CODEC_FILE_ERROR;

           }

#elif defined(_DBG_MP2_BS) //!USE_USBIO, pre-debugg facility, liyenho

      if ((pdbg+(num_output_bytes_produced)) > pdbgEnd)

         pdbg = (char*) dbg_mp2_buffer;

      //if ((pdbg+(num_output_bytes_produced)) <= pdbgEnd)

      {

         memcpy((void*)pdbg,(void*)bitstream_buffer,num_output_bytes_produced);

/****************************************

int n,cc;

   for(n=0;n<1152;n++)

      for(cc=0;cc<2;cc++)

         *((short*)pdbg+n*2+cc) = enc_input_pcm_channels[cc][2*n];

****************************************/

         pdbg += (num_output_bytes_produced);

      }

#endif

                                  #ifdef YH_TIMECHECK

                                      time_end_enc = clock();   //YH

                                  #endif



#ifndef _FOR_FUN // real mode operation

        do

       {   // added by liyenho for ping pong (dac) buffer carrying audio bit stream

         pFifoBuffer1 = (int*)usr_getpcmbuffer(1/*tx*/,pcm_data_block_length); // be sure NOT to re-use tx fifo

        } while (pFifoBuffer1 == 0);

#if defined(_DBG_FPGA_RECV)

#if 0 // validate bit stream transport using two channel scope, liyenho

         for (j=0 ;j<enc_nNumSamples;j++)

         {

            bit_stream_pattern[j*2+0] = (0xf0f00000>>0/*3*/)>>8;

            bit_stream_pattern[j*2+1] = (0x0f0f0000)>>8;

         }

#else // scope the audio frame timing, liyenho

         memset(bit_stream_pattern,0x0,enc_nNumSamples*4*2);

            bit_stream_pattern[0] = (0xf0f00000>>0/*3*/)>>8;

            bit_stream_pattern[1] = (0x0f0f0000)>>8;

#endif

#ifndef _LOW_DELAY

         j = usr_writepcmblock(1/*tx*/,pcm_data_block_length*4, (char*)bit_stream_pattern);

#endif

#else   //!_DBG_FPGA_RECV

        // copy bit stream buffer into temp fifo mem for tx dma...

        unsigned char chksum = 0;

        short *pbs = (short*)bitstream_buffer;

         i = num_output_bytes_produced/2;



        for (j=0; j<i; j++) //process 4bytes per loop

        {

           bit_stream_pattern[j] = (*(pbs++) << ((16)-0/*3*/))>>8;

            chksum+= (unsigned char)(bit_stream_pattern[j]>>8);

            chksum+= (unsigned char)(bit_stream_pattern[j]>>16);

         }

        if (1&(num_output_bytes_produced)) // odd byte case

         {

            bit_stream_pattern[i] = (((*(char*)pbs++)&0x000000ff)<<8); //LSB is i2s MSB (flipped)

            chksum+= (unsigned char)(bit_stream_pattern[i]>>8);

            i = i + 1; // one more used

         }



            if (1&(num_output_bytes_produced))

            {

              bit_stream_pattern[i-1] |= (((int)chksum)<<(16)  );  //odd frame size case

            }

            else // enc bytes produced are even #

            {

               bit_stream_pattern[i] = (((int)chksum)<<(8)  );

               i = i + 1; // one more used

            }

         for (j=i; j<pcm_data_block_length; j++) bit_stream_pattern[j] = 0; // clean up the junk @ end



         #ifdef YH_DMA_TX_DIRECT

         //YH: Direct write to DMA buffers

         if(dma_tx_wr_select==1)   //YH: "1" was manually tuned so no fragement output observed with YH_TIMECHECK turned on

         {

           memcpy((void *)iDACdata1, (void *)bit_stream_pattern, (DAC_CHANNEL_NUMBER * ADAC_BUFFER_SIZE*4));

           //PATCH: YH: observed startup flipped dam_tx_wr_select. Force both dma buff for now

           #ifdef YH_DMA_WR_PATCH

           memcpy((void *)iDACdata2, (void *)bit_stream_pattern, (DAC_CHANNEL_NUMBER * ADAC_BUFFER_SIZE*4));

           #endif

                   #ifdef YH_TIMECHECK

                      dma_test_val++;

                      if(dma_test_val%2==0)

                         memset((void *)iDACdata1, 0xff, (DAC_CHANNEL_NUMBER * ADAC_BUFFER_SIZE*4));

                      else

                         memset((void *)iDACdata1, 0x0f, (DAC_CHANNEL_NUMBER * ADAC_BUFFER_SIZE*4));

                   #endif

           flush_data_buffer((void *)iDACdata1, (void *)((int)iDACdata1+(DAC_CHANNEL_NUMBER * ADAC_BUFFER_SIZE*4)), 1);

           flush_data_buffer((void *)iDACdata2, (void *)((int)iDACdata2+(DAC_CHANNEL_NUMBER * ADAC_BUFFER_SIZE*4)), 1);



         }

         else{

           memcpy((void *)iDACdata2, (void *)bit_stream_pattern, (DAC_CHANNEL_NUMBER * ADAC_BUFFER_SIZE*4));

           //PATCH: YH: observed startup flipped dam_tx_wr_select. Force both dma buff for now

           #ifdef YH_DMA_WR_PATCH

           memcpy((void *)iDACdata1, (void *)bit_stream_pattern, (DAC_CHANNEL_NUMBER * ADAC_BUFFER_SIZE*4));

           #endif

                       #ifdef YH_TIMECHECK

                          memset((void *)iDACdata2, 0x0, (DAC_CHANNEL_NUMBER * ADAC_BUFFER_SIZE*4));

                       #endif

           flush_data_buffer((void *)iDACdata2, (void *)((int)iDACdata1+(DAC_CHANNEL_NUMBER * ADAC_BUFFER_SIZE*4)), 1);

           flush_data_buffer((void *)iDACdata1, (void *)((int)iDACdata2+(DAC_CHANNEL_NUMBER * ADAC_BUFFER_SIZE*4)), 1);

         }

         #else

         // Original fifo write to fifo.c modules

         j = usr_writepcmblock(1/*tx*/,pcm_data_block_length*4, (char*)bit_stream_pattern);

         if (pcm_data_block_length != (j>>2)) printf("tx mem copy fails...\n");

         #endif



#endif

#ifdef _TCPIP

   extern int Trace_Socket,udpout_len;

   extern struct sockaddr_in udpout;

      int err;

      //err = /*lwip_*/send(Trace_Socket,

      //                           (void*)bitstream_buffer,

      //                           num_output_bytes_produced,

      //                           0);

      err = /*lwip_*/sendto(Trace_Socket, (void*)bitstream_buffer,

                                 num_output_bytes_produced,0,

                                 (struct sockaddr *)&udpout,udpout_len);

      if (0>err) printf("tcp/udp send failed\n");

#endif //_TCPIP

#endif

#endif

       }

testCount = testCount - 1;

        if (ezIsButtonPushed(0)

#ifdef _UART_CONFIG

            || (0 != mp2_request_reconfig)

#endif

        )

        {

updateFlag = 0;

#ifdef _LOW_DELAY

   updateFlag1 = 0;

#endif

            while(ezIsButtonPushed(0));

         #if defined(__ADSP_EDINBURGH__)   // BF533

            printf("SW4 Button pressed: skipping to next file\n");

         #endif



         #if defined(__ADSP_KOOKABURRA__)  // BF527

               printf("PB2 Button pressed: skipping to next file\n");

         #endif



         #if defined(__ADSP_MOAB__)  // BF548

            printf("PB1 Button pressed: skipping to next file\n");

         #endif



         #if defined(__ADSP_BRAEMAR__)  // added by liyenho

            printf("SW13 Button pressed: skipping to next file\n");

#ifndef _LOW_DELAY

   extern volatile bool  ready_proc_rx_isr;  // flag for isr kick off,

   extern volatile bool  ready_proc_tx_isr;  // flag for isr kick off,

            ready_proc_rx_isr = ready_proc_tx_isr= 0; // stop dma services, liyenho

                                                      // forced hi in adac_buff.c YH

#endif

            break;

        }

#ifdef _LOW_DELAY // low delay design

         adcBuffIdx1 = 1 ^ adcBuffIdx1;

   extern void sys_msleep(u32_t ms); // to facilitate tcpip process, liyenho

         while (adcBuffIdx1 != adcBuffIdx) sys_msleep(1);

#endif

   }

   // clean up the mess after encoding finishes

   MPA_encode_close(&avctx);

   av_free(avctx.priv_data);

#ifndef _LOW_DELAY

   printf("testCount = %d\n",testCount);

#else // low delay design

   printf("testCount0 = %d\ntestCount1 = %d",testCount0,testCount1);

#endif

#ifdef USE_USBIO

   fclose(fileout);

#endif

   return CODEC_SUCCESS;

}



int get_encode_param(FILE *fileptr)

{

   int nf = 0;



#define ADD_SAMPLE_RATE_PARAM       (1)

#ifdef USE_USBIO

#if ADD_SAMPLE_RATE_PARAM

   nf = fscanf(fileptr, "%s %d %d %s %s %d\n",

   current_output_file_name,

   &config_param.avg_bitrate_bps,

   &config_param.num_channels,

   enc_type,

   enc_format,

   &config_param.sample_rate

   );

#else

   nf = fscanf(fileptr, "%s %d %d %s %s\n",

   current_output_file_name,

   &config_param.avg_bitrate_bps,

   &config_param.num_channels,

   enc_type,

   enc_format);

    config_param.sample_rate = 48000;  //default

#endif

#else //!USE_USBIO

#ifndef _UART_CONFIG

   // hard wire these audio enc config settings, liyenho

   config_param.avg_bitrate_bps = 128000;

#endif

   config_param.num_channels = 2;

   config_param.sample_rate = 48000;

   strcpy(enc_format,"adts");

#endif //!USE_USBIO

    if((config_param.num_channels != 1) && (config_param.num_channels != 2)) config_param.num_channels = 2;  // default

#ifndef _UART_CONFIG

/* encoder_type, is not used in mp2 encoder */

   strcpy(enc_type,"v1");

    if ( strcmp (enc_type, "v1") == 0 ) config_param.encoder_type = 1;

    else config_param.encoder_type = 2;  // default

#else //_UART_CONFIG

      mp2_request_reconfig = 0;  // clear config request flag, liyenho

      nf = 2;

      if (!config_param.encoder_type)

         nf = 0;  // fpga host request to stop audio encoding..., liyenho

#endif

    config_param.bitstream_format = 2;  // default

   if ( strcmp (enc_format, "raw") == 0 ) config_param.bitstream_format = 0;

   if ( strcmp (enc_format, "adif") == 0 ) config_param.bitstream_format = 1;

   if ( strcmp (enc_format, "adts") == 0 ) config_param.bitstream_format = 2;



    return nf;

}



void print_encode_param()

{

   printf("\t sample rate: %d\n", config_param.sample_rate);

   printf("\t requested bit rate: %d\n", config_param.avg_bitrate_bps);

   printf("\t num of channels: %d\n", config_param.num_channels);

#ifndef _UART_CONFIG

   printf("\t encoder type: %s\n", &enc_type);

#else //_UART_CONFIG

   printf("\t encoder type: v%d\n", config_param.encoder_type);

#endif

   printf("\t bistream format: %s\n", &enc_format);

}

#endif //MP2_ENC



#ifdef YH_I2SCNTCHECK

void memchk(int * block)

{

   int i,j;

        memcpy(memchkarray, block, ADAC_BUFFER_SIZE*2*4); //breakpoint monitor only

      for(ivv=0;ivv<ADAC_BUFFER_SIZE;ivv++)

      {

        for(j=0;j<2;j++)

        {

            if(j==0)

            {

              val_prev = val_curr;

              val_curr = (unsigned short)(block[2*ivv+j]);

              if((val_curr - val_prev !=1)&&(val_curr!=0xffff)&&(val_prev!=0xffff))

                error_cnt2++;

            }



            //if((error_cnt2==200)||(pktcnt==250))

            //{

            //   //garbage code to prevent optimizer remover

            //   for(i=0;i<10;i++)

            //     *(block+i) = block[ivv] + clock();

            //}



        }

      }



   pktcnt++;

   /*

   if(pktcnt==1)

            {

               for(i=0;i<10;i++)

                 *(memchkarray+i) = memchkarray[iv] + clock();

            }

    */

}

#endif

