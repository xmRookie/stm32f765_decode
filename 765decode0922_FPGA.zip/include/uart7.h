
#ifndef __USART7_UART_H__
#define __USART7_UART_H__

extern void MX_UART7_Init(void);


#endif
