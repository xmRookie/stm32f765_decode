
#ifndef __SPI5_H__
#define __SPI5_H__

extern void MX_SPI5_Init(void);

extern void SPI5_TxCpltCallback(void);

extern void Pollint_Spi5(void);

extern void spi5_video_output(uint8_t *dat,uint16_t len,uint8_t lastflag);

extern void En_RX_Flow_Ctrl(void);


#endif //__SPI5_H__
