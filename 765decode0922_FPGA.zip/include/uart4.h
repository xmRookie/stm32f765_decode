
#ifndef __USART_UART4_H__
#define __USART_UART4_H__

extern void MX_UART4_Init(void);


#endif
