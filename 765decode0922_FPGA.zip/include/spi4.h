
#ifndef __SPI4_H__
#define __SPI4_H__

extern void MX_SPI4_Init(void);


#endif //__SPI4_H__
