#ifndef __MP2_H__
#define __MP2_H__

extern void MP2_init(void);

int MP2_Encode(short *buf,int len);

extern void mp2_put_dat(uint8_t *dat,uint16_t len,uint8_t lastflag);

extern void Pollint_Mp2(void);

extern void MP2_Decode_Init(void);

extern void mp2_decode(uint8_t *dat,uint16_t len,short *audio_out_stream);

#endif  /*__MP2_H__ */
