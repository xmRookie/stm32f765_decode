#ifndef __I2C2_H__
#define __I2C2_H__

extern void MX_I2C2_Init(void);


#endif //__I2C2_H__
