

#include "common.h"


#define TS_VIDEO_PID  256
#define TS_AUDIO_PID  257

#define H265_HEAR_LEN   81 //28vps 35sps 11pps  7idr = 28+35+11+7=81
#define TS_VIDEO_PES_LEN  26

#define TS_AV_NOR_LEN  4


#define TS_AUDIO_PES_LEN  20

#define S_VIDEO_PID 0x4100
#define S_AUDIO_PID 0x4101

typedef struct {
	uint8_t is_start;
	uint8_t cc;
	uint16_t pid;
	uint16_t stuf_len;
	int payload_size;
	int cnt;
	int precnt;

} AV_TS_STREAM;


AV_TS_STREAM  video_stream;
AV_TS_STREAM  audio_stream;


static uint8_t pat_pmt_cc;


//aud  0x0, 0x0, 0x0, 0x1, 0x9, 0x30,
//sps 0x0, 0x0, 0x0, 0x1, 0x67, 0x64, 0x0, 0x28, 0xac, 0x15, 0xa0, 0x14, 0x1, 0x6e, 0x84, 0x0, 0xd, 0xbb,0xa0, 0x6, 0x6f, 0xf3, 0x2, 0x10,
//pps 0x0, 0x0, 0x0, 0x1, 0x68, 0xee, 0x3e, 0x30,
//sei  0x0, 0x0, 0x0, 0x1, 0x6, 0x6, 0x1, 0xa4, 0x80,



extern void tsMux_init(void)
{

    pat_pmt_cc = 0;
	video_stream.is_start = 0;
    video_stream.pid = 256;
	video_stream.cnt = 0;
    video_stream.cc = 15;
	
	audio_stream.is_start = 0;
    audio_stream.pid = 257;
    audio_stream.cc = 15;
	audio_stream.cnt = 0;

}




extern Boolean TsDemuxPAT(uint8_t *pbuf,uint16_t len)
{
	uint8_t cc;
	cc = pbuf[3] & 0x0f;
	
	if(pbuf[0] != 0x47 && len != 376)
	{
		return FALSE;
	}
	pat_pmt_cc = (pat_pmt_cc + 1) & 0xf;
	 
	if(cc != pat_pmt_cc)
	{
//		printf("pat cc is %d \r\n",cc);
		pat_pmt_cc = cc;
	}
	video_stream.is_start = 1;
//	Led_Test1();	
	Client_flow_state(0);
	return TRUE;
	
	
}

static uint16_t getPid(uint8_t *buf)
{
	uint8_t bufH;
	bufH = buf[0] & 0x0f;
	return ((bufH * 0x100) + buf[1]);
}




static void  DecodeMpegVideo(uint8_t *buf,uint16_t len)
{
	uint8_t offset = 0;
	uint8_t stuf_len;
	uint8_t endflag = 0;
	
	uint8_t i=0;
	
	 if(buf[1]&0x40)//start frame
	 {
		if(video_stream.cnt != video_stream.precnt)
		{
		//	printf("video sum cnt %d\r\n",video_stream.cnt);
			video_stream.precnt = video_stream.cnt;
		}
		video_stream.cnt = 0;
		offset =  TS_VIDEO_PES_LEN;   //26
	 }
	 else if(buf[3] < 0x30)
	 {
		offset = TS_AV_NOR_LEN;
	 }
	 else 
	 {
	 	stuf_len = buf[4];  //0x6a   0xa1
		 
		 
		 if(stuf_len == 0x6a){
				offset = TS_AV_NOR_LEN+stuf_len+1;   //
				endflag = 1;
		 }else{
				offset = TS_AV_NOR_LEN;
		 }
	
	//	 printf("%x ",buf[4]);
#if 0	 
		 for(i=0; i<188; i++)
				printf("%x ",buf[i]);
		 printf("\r\n");
#endif		 
	 }
	 len -= offset;
	 
	 video_stream.cnt++;

	// spi5_video_output(buf+offset,len,endflag);
}


static void  DecodeMpegAudio(uint8_t *buf,uint16_t len)
{
	uint8_t offset = 0;
	uint8_t stuf_len;
	uint8_t endflag = 0;
	
	 if(buf[1]&0x40)//start frame
	 {
		if(audio_stream.cnt != audio_stream.precnt)
		{
			printf("video sum cnt %d\r\n",audio_stream.cnt);
			audio_stream.precnt = audio_stream.cnt;
		}
		audio_stream.cnt = 0;
		offset =  TS_AUDIO_PES_LEN;
	 }
	 else if(buf[3] < 0x30)
	 {
		offset = TS_AV_NOR_LEN;
	 }
	 else 
	 {
	 	stuf_len = buf[4];  //0x77
		offset = TS_AV_NOR_LEN+stuf_len+1;  //4 + 119(0xff) + 1(0x00)
		endflag = 1;
	 }
	 
	 len -= offset;
	 
	 audio_stream.cnt++;

	 Led_Test1();
	 
	 mp2_put_dat(buf+offset,len,endflag);
	
}


extern Boolean TsDemuxAV(uint8_t *pbuf,uint16_t len)
{
	uint8_t cc;
	uint16_t pid;
	
	cc = pbuf[3] & 0x0f;

	pid = getPid(&pbuf[1]);
	
	if(pbuf[0] != 0x47 && len != 188)
	{
		printf("no 0x47");
		return FALSE;
	}

	if(pid == 256)//video
	{
		 video_stream.cc = (video_stream.cc + 1) & 0xf;
	 
		if(cc != video_stream.cc)
		{
			printf("v cc is %d \r\n",cc);
			video_stream.cc = cc;
		}
	//	Led_Test1();
		DecodeMpegVideo(pbuf,len);
	}
	else
	{
		audio_stream.cc = (audio_stream.cc + 1) & 0xf;
	 
		if(cc != audio_stream.cc)
		{
			printf("a cc is %d \r\n",cc);
			audio_stream.cc = cc;
		}
	//	Led_Test1();
		DecodeMpegAudio(pbuf,len);
	}

	return TRUE;
	
	
}



