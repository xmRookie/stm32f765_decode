#include "common.h"

I2S_HandleTypeDef hi2s2;

extern uint8_t audio_stream_in_buf[][1152];

typedef struct {
    volatile uint16_t       Write;
    volatile uint16_t       Read;
    volatile Boolean        HaveData;
    uint8_t                 busy;
} I2S_STREAM;

static I2S_STREAM i2sStream;


#define i2s2_rx_buf_size 2304//1152//4608 
#define I2S_BUFNB 4


short  i2s2_rx_buf[I2S_BUFNB][i2s2_rx_buf_size];

DMA_HandleTypeDef hdma_spi2_tx;


/* I2S2 init function */
extern void MX_I2S2_Init(void)
{

  hi2s2.Instance = SPI2;
  hi2s2.Init.Mode = I2S_MODE_MASTER_TX;
  hi2s2.Init.Standard = I2S_STANDARD_PHILIPS;
  hi2s2.Init.DataFormat = I2S_DATAFORMAT_16B_EXTENDED;  //I2S_DATAFORMAT_16B;  //I2S_DATAFORMAT_24B;  //
  hi2s2.Init.MCLKOutput = I2S_MCLKOUTPUT_DISABLE;
  hi2s2.Init.AudioFreq = I2S_AUDIOFREQ_48K;
  hi2s2.Init.CPOL = I2S_CPOL_LOW;
  hi2s2.Init.ClockSource = I2S_CLOCK_PLL;
  if (HAL_I2S_Init(&hi2s2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}


extern short *get_Out_I2S_Buf(void)
{
	
	uint16_t head;
	short *p;

    head = RBUF_NEXT_PT(i2sStream.Write, 1, I2S_BUFNB);

    if(head == i2sStream.Read) { //?��
			printf("g");
         return NULL;
    }
	p = i2s2_rx_buf[i2sStream.Write];
	//	p = (short *)audio_stream_in_buf[i2sStream.Write];   //for test
	
	i2sStream.Write = head;
	
	return p;

}

extern void I2S2_Enable_Send(void)
{
    if(i2sStream.HaveData == 0) 
			{
        i2sStream.HaveData = 1;
			//	printf("%x ",i2s2_rx_buf[i2sStream.Read][100]);
    		HAL_I2S_Transmit_DMA(&hi2s2, (uint16_t *)&i2s2_rx_buf[i2sStream.Read], i2s2_rx_buf_size);
			//HAL_I2S_Transmit_DMA(&hi2s2, (uint16_t *)&audio_stream_in_buf[i2sStream.Read], i2s2_rx_buf_size);  //for test
        i2sStream.Read = RBUF_NEXT_PT(i2sStream.Read, 1, I2S_BUFNB);
			
    }
}

extern void I2S2_TxCpltCallback(void)
{
	if(i2sStream.Write == i2sStream.Read) {
        i2sStream.HaveData = 0;
    } else {
        HAL_I2S_Transmit_DMA(&hi2s2, (uint16_t *)&i2s2_rx_buf[i2sStream.Read], i2s2_rx_buf_size);
			printf("cb ");
		//	HAL_I2S_Transmit_DMA(&hi2s2, (uint16_t *)&audio_stream_in_buf[i2sStream.Read], i2s2_rx_buf_size);  //for test
        i2sStream.Read = RBUF_NEXT_PT(i2sStream.Read, 1, I2S_BUFNB);
    }
}


extern void HAL_I2S_TxCpltCallback(I2S_HandleTypeDef *hi2s)
{
	if(hi2s->Instance == SPI2)
	{
		I2S2_TxCpltCallback();
	}
}


