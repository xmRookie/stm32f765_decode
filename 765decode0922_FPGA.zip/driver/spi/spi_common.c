#include "common.h"


extern void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi)
{
	if(hspi->Instance == SPI5) {
		//SPI5_RxCpltCallback();
	}
}

extern void HAL_SPI_M1RxCpltCallback(SPI_HandleTypeDef *hspi)
{
		if(hspi->Instance == SPI5) {
		//SPI5_M1RxCpltCallback();
		}
}

//extern void HAL_SPI_RxHalfCpltCallback(SPI_HandleTypeDef *hspi)
//{
//	if(hspi->Instance == SPI5) {
//		SPI5_RxHalfCpltCallback();
//	}
//}

extern void HAL_SPI_TxCpltCallback(SPI_HandleTypeDef *hspi)
{
		
		if(hspi->Instance == SPI1)
		{
			SPI1_TxCpltCallback();
		}
		else if(hspi->Instance == SPI5) {
			SPI5_TxCpltCallback();
		}
}



extern  void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi)
{
			
}

