
#ifndef __I2S2_H__
#define __I2S2_H__

extern void MX_I2S2_Init(void);

extern void I2S2_Enable_Send(void);

extern short *get_Out_I2S_Buf(void);

extern void HAL_I2S_TxCpltCallback(I2S_HandleTypeDef *hi2s);


#endif //__I2S2_H__
