#ifndef __LED_H_
#define __LED_H_

extern void led_Par_Init(void);
extern void MX_LED_Init(void);
extern void Led_Test(void);
extern void Status_busy(uint8_t st);

extern void Led_Test1(void);

//extern void Led1_Set(Boolean status);
//extern void Led2_Set(Boolean status);

#endif /*__LED_H_*/
