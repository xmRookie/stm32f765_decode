#ifndef __UDP_API_H
#define __UDP_API_H
#ifdef __cplusplus
 extern "C" {
#endif

extern void udp_echoclient_connect(void);

extern void udp_TimerTick(void);

extern uint8_t get_remoteLwip_udp_link(void);



//extern uint8_t udp_Send_Pack(uint8_t *buf, uint16_t len);
extern void udp_Send_Pack(uint8_t *buf1, uint16_t len1,uint8_t *buf2, uint16_t len2);
	 
	 
extern void nicIP(uint8_t *netBuffer,uint16_t len);

	 
extern void set_remoteLwip_udp_link(uint8_t link);

#ifdef __cplusplus
}
#endif
#endif /* __UDP_API_H */
