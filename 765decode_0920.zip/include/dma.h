
#ifndef __DMA_H__
#define __DMA_H__


extern void MX_DMA_Init(void);


#endif //__DMA_H__
