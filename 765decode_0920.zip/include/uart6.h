
#ifndef __USART6_UART_H__
#define __USART6_UART_H__

extern void MX_USART6_UART_Init(void);


#endif
