
#ifndef __I2C1_H__
#define __I2C1_H__

extern void MX_I2C1_Init(void);


#endif //__I2C1_H__
