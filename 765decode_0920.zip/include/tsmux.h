#ifndef __LITETS_TSSTREAM_H__
#define __LITETS_TSSTREAM_H__

/************************************************************************/
/* little-endian                                                        */
/************************************************************************/
//typedef unsigned char  uint8_t;
//typedef unsigned short uint16_t;
//typedef unsigned int  uint32_t;
//typedef unsigned long int uint64_t;
//typedef long int  int64_t;


extern void tsMux_init(void);

extern Boolean TsDemuxPAT(uint8_t *pbuf,uint16_t len);

extern Boolean TsDemuxAV(uint8_t *pbuf,uint16_t len);


#endif //__LITETS_TSSTREAM_H__
