#ifndef __I2C3_H__
#define __I2C3_H__

extern void MX_I2C3_Init(void);


#endif //__I2C3_H__
