
#ifndef __USART2_UART_H__
#define __USART2_UART_H__

extern void MX_USART2_UART_Init(void);


#endif
