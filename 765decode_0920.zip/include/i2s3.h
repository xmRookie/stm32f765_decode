
#ifndef __I2S3_H__
#define __I2S3_H__

extern void MX_I2S3_Init(void);


#endif //__I2S3_H__
