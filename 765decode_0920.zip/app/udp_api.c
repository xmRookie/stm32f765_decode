
#include "common.h"
#include "ethernetif.h"
//extern struct netif gnetif;
/* Global Ethernet handle */
extern ETH_HandleTypeDef heth;



extern NETIF_PAR netif_par;
extern NETIF_REMOTE_PAR netif_remote_par;


static uint8_t link_state = 0;
/** The IP header ID of the next outgoing IP packet */
static u16_t ip_id;



typedef struct {
    uint8_t dest_mac[6];
    uint8_t src_mac[6];
    uint8_t type[2];
} EtherHdr;

typedef struct
{
    uint8_t                  hardware[2];       // Hardware
    uint8_t                  protocol[2];       // Protocol
    uint8_t                  HL_PL[2];          // Hardware Address Length(8 bit) : Protocol Address Length(8 bit)
    uint8_t                  op[2];             // Operation
    uint8_t                  sedmac[6];      // Sender Hardware Address
    uint8_t                  sedip[4];          // Sender Internet Address
    uint8_t                  trgmac[6];      // Target Hardware Address
    uint8_t                  trgip[4];          // Target Internet Address
} ARPPACKA_TYPE;


typedef struct {
    uint8_t                  socpot[2];                     // 请求端端口
    uint8_t                  dstpot[2];                     // 服务器端口
    uint8_t                  len[2];                     // UDP数据长度
    uint8_t                  chksum[2];                     // UDP包校验核

} UDPPACKA_TYPE;


typedef struct {
    uint8_t                  V_H_T[2];          // Version(4 bit) : Header Length(4 bit) : Type of Service(8 bit)
    uint8_t                  totlen[2];         // Total Length
    uint8_t                  idtf[2];           // Identifier
    uint8_t                  FLA_OFS[2];        // Eragmentation Flags(3 bit) : Eragment Offset(13 bit)
    uint8_t                  LIVE_PTC[2];       // Time To Live(8 bit) : Protocol(8 bit)
    uint8_t                  chksum[2];       // Header Checksum
    uint8_t                  socip[4];          // Sourct IP Address
    uint8_t                  dstip[4];          // Dest. IP Address
} IPPACKA_TYPE;



typedef struct {
    EtherHdr               eth;           // 14
    IPPACKA_TYPE           ipH;            // 20
    UDPPACKA_TYPE          udpH;            // 8
} NETPACKA_TYPE;


typedef struct {
    EtherHdr               eth;           // 14
    ARPPACKA_TYPE           arp;            // 28

} NETPACKA_ARP_TYPE;

NETPACKA_TYPE   netUdpPack;
//NETPACKA_ARP_TYPE netArpPack;

static void U16_To_HexBuf(uint8_t *dest, uint16_t bin)
{
    *dest++ = bin >> 8;
    *dest = bin;
}

static uint16_t HexBuf_To_U16(uint8_t *src)
{
    return ((src[0] * 0x100) + src[1]);
}


u16_t get_ip_id(void)
{
	return ip_id;
}

void Inc_ip_id(void)
{
	++ip_id;
}


extern uint8_t get_remoteLwip_udp_link(void)
{
    return link_state;
}


extern void set_remoteLwip_udp_link(uint8_t link)
{
	if(link)
		link_state = NET_LINKED;
	else
		link_state = NET_UNLINK;
}


//功能  ARP数据包的发送函数 //ARP的数据长度是42个字节
//输入  op  ARP的操作码 
//输出
//返回
static void sendArp(uint8_t op)
{
    NETPACKA_ARP_TYPE *txpt;
    uint8_t TxBuf[0x100];

    txpt = (NETPACKA_ARP_TYPE *)TxBuf;
    U16_To_HexBuf(txpt->arp.hardware, 0x0001);
    U16_To_HexBuf(txpt->arp.protocol, 0x0800);
    txpt->arp.HL_PL[0] = 0x06;
    txpt->arp.HL_PL[1] = 0x04;
    U16_To_HexBuf(txpt->arp.op, op);
    memcpy(txpt->arp.sedmac, netif_par.mac, 6);
    memcpy(txpt->arp.sedip, netif_par.ip, 4);
    if (op == 1)
    {   // ARP 请求
        memset(txpt->arp.trgmac, 0x00, 6);
		memset( netif_remote_par.mac,0xff, 6);
    }
    else
    {   // ARP 应答
        memcpy(txpt->arp.trgmac, netif_remote_par.mac, 6);
    }
    memcpy(txpt->arp.trgip, netif_remote_par.ip, 4);

	memcpy(txpt->eth.dest_mac, netif_remote_par.mac, 6);
    memcpy(txpt->eth.src_mac, netif_par.mac, 6);
    U16_To_HexBuf(txpt->eth.type, P_ARP);
	udp_ts_output(TxBuf,42);
}


//功能  ARP功能函数，主要用于查询和回答相应的MAC地址
//      硬件类型(16)            协议类型(16)
//      硬件长度(8) 协议长度(8) 操作(16)
//              发送站硬件地址
//              发送站协议地址
//              目标站硬件地址
//              目标站协议地址
//输入
//输出
//返回
static void arpFun(uint8_t *netBuffer)
{
    NETPACKA_ARP_TYPE *rxpt;

    rxpt = (NETPACKA_ARP_TYPE *)netBuffer;
    if (rxpt->arp.op[0] != 0)
    {   //ARP的高位操作码非法
        return;
    }                  
    switch (rxpt->arp.op[1])
    {
        case 1:     //ARP请求操作,这里发送请求应答
		    if (memcmp(netif_remote_par.ip, rxpt->arp.sedip, 4) == 0)
		   	{
		   	   memcpy(netif_remote_par.mac,rxpt->arp.sedmac, 6);
               sendArp(2);
			   set_remoteLwip_udp_link(1);
		   	}
            break;
        default:
            return;
    }
    
}

static void udpFun(uint8_t *netBuffer,uint16_t len)
{
    NETPACKA_TYPE *rxpt;
	uint16_t datlen;
	
    rxpt = (NETPACKA_TYPE *)netBuffer;

	datlen = HexBuf_To_U16(rxpt->udpH.len)-UDP_HLEN;
	
    if(len==418 && datlen == 376)
    {
    	TsDemuxPAT(netBuffer+42,datlen);
	}
	
	else if (len==230 && datlen == 188)
	{
		TsDemuxAV(netBuffer+42,datlen);
		
	}
}

extern void nicIP(uint8_t *netBuffer,uint16_t len)
{

    EtherHdr *rxpt;

    rxpt = (EtherHdr *)netBuffer;

	 

    switch(HexBuf_To_U16(rxpt->type))          
    {
        case P_ARP:                                 
            arpFun(netBuffer);
            break;
        case P_RARP:                               
            break;
        case P_IP:    
			if (memcmp(netif_par.mac, rxpt->dest_mac, 6) == 0)//判断是是否发给我们的
			{
				 udpFun(netBuffer,len);//376 or 188 or 42
			}
            
            break;
        default:
            break;
    }
}








extern void udp_TimerTick(void)
{
	

}


extern void udp_Send_Pack(uint8_t *buf1, uint16_t len1,uint8_t *buf2, uint16_t len2)
{
	uint16_t id;
	uint32_t ret;
	volatile uint16_t i;
	PBUF mPortBuf;
	
	i = len1+len2;
	mPortBuf.len = i;

	Inc_ip_id();
	id = get_ip_id();
	U16_To_HexBuf(netUdpPack.ipH.idtf, id);

	i += UDP_HLEN;
	U16_To_HexBuf(netUdpPack.udpH.len, i);
	i += IP_HLEN;
	U16_To_HexBuf(netUdpPack.ipH.totlen, i);


	mPortBuf.tot_len = i + LINK_HLEN;

	mPortBuf.payload = (void *)&netUdpPack;
	ret = len1+len2;
	if(udp_ts_output2( &mPortBuf, buf1,len1,buf2,len2) != ret){
		USART3_Putchar(6);
	}

}





//UDP
extern void udp_echoclient_connect(void)
{
    uint16_t id;
    uint16_t len;

	link_state = NET_UNLINK;

	/** The IP header ID of the next outgoing IP packet */
	ip_id = 0;

    len = 0;
    len += UDP_HLEN;

    U16_To_HexBuf(netUdpPack.udpH.socpot, netif_par.port);
    U16_To_HexBuf(netUdpPack.udpH.dstpot, netif_remote_par.port);

    U16_To_HexBuf(netUdpPack.udpH.len, len);
    netUdpPack.udpH.chksum[1] =  netUdpPack.udpH.chksum[0] = 0;


    len += IP_HLEN;
    netUdpPack.ipH.V_H_T[0] = 0x45;
    netUdpPack.ipH.V_H_T[1] = 0x00;
    U16_To_HexBuf(netUdpPack.ipH.totlen, len);
    //Inc_ip_id();
    id = get_ip_id();
    U16_To_HexBuf(netUdpPack.ipH.idtf, id);
    U16_To_HexBuf(netUdpPack.ipH.FLA_OFS, 0x0000);
    netUdpPack.ipH.LIVE_PTC[0] = 0xFF;//ttl
    netUdpPack.ipH.LIVE_PTC[1] = 0x11;//proto
    memcpy(netUdpPack.ipH.socip, netif_par.ip, 4);
    memcpy(netUdpPack.ipH.dstip, netif_remote_par.ip, 4);
    netUdpPack.ipH.chksum[1] =  netUdpPack.ipH.chksum[0] = 0;

    memcpy(netUdpPack.eth.dest_mac, netif_remote_par.mac, 6);
    memcpy(netUdpPack.eth.src_mac, netif_par.mac, 6);
    U16_To_HexBuf(netUdpPack.eth.type, 0x0800);

}

