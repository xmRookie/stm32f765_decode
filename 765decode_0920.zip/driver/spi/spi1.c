#include "common.h"

SPI_HandleTypeDef hspi1;

#define TS_LEN 0x2000

DMA_HandleTypeDef hdma_spi1_rx;
DMA_HandleTypeDef hdma_spi1_tx;
__IO uint8_t  io_isq_flag = 0;
__IO uint8_t  resend_key_flag = 0;
__IO uint8_t enPollint;
__IO uint8_t Tx_end_flag;
uint16_t index;
static uint8_t spi1_tx_buf[TS_LEN];
//static uint8_t spi1_rx_buf[spi_rx_buf_Number];


void flow_ctrl_set(Boolean status)
{
    if(status) {
        HAL_GPIO_WritePin(GPIOG, GPIO_PIN_1, GPIO_PIN_SET);
    } else {
        HAL_GPIO_WritePin(GPIOG, GPIO_PIN_1, GPIO_PIN_RESET);
    }
}


extern void SPI1_TxCpltCallback(void)
{
		//printf("spi1 send end2\n");
		flow_ctrl_set(1);
}

/* SPI1 init function */
extern void MX_SPI1_Init(void)
{
	uint32_t i;
    /* SPI1 parameter configuration*/
    hspi1.Instance = SPI1;
    hspi1.Init.Mode = SPI_MODE_MASTER;
    hspi1.Init.Direction = SPI_DIRECTION_2LINES;
    hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
    hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
    hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
    hspi1.Init.NSS = SPI_NSS_SOFT;//SPI_NSS_SOFT;//SPI_NSS_HARD_OUTPUT;
    hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
    hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
    hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
    hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
    hspi1.Init.CRCPolynomial = 7;
    hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
    hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;

    if(HAL_SPI_Init(&hspi1) != HAL_OK) {
        _Error_Handler(__FILE__, __LINE__);
    }
	spi1_tx_buf[0] = 0xff;
	spi1_tx_buf[1] = 0xff;
	spi1_tx_buf[2] = 0x00;
	spi1_tx_buf[3] = 0x00;
	for(i=4;i<sizeof(spi1_tx_buf);i++)
	{
		spi1_tx_buf[i] = i-4;
	}
	//memset((uint8_t *)&spi1_tx_buf[0],0x55, sizeof(spi1_tx_buf));
	setenPollint(0);
	Tx_end_flag =1;
	index= 0;
	//flow_ctrl_gpio();
	//flow_ctrl_set(1);
}



extern void SPI1_Flow_deal(void)
{
	 if(HAL_GPIO_ReadPin(GPIOG, GPIO_PIN_2) == GPIO_PIN_RESET) { //�½���  ����spi

		if(io_isq_flag)
		{
		    //printf("spi1 isq down\n");
		    io_isq_flag =0;
			__HAL_SPI_ENABLE(&hspi1);
		
			if(resend_key_flag)
			{
				resend_key_flag = 0;
				if(HAL_SPI_Transmit_IT(&hspi1, (uint8_t *)&spi1_tx_buf[0], TS_LEN) != HAL_OK)
				{
					printf("error spi master send \n");
				}
			}
		}
		
	}
	else if(HAL_GPIO_ReadPin(GPIOG, GPIO_PIN_2) == GPIO_PIN_SET) { //������  �ر�spi
		//__HAL_DMA_DISABLE(&hdma_spi5_rx);  //ʹ��dma
		//printf("spi1 isq up\n");
		io_isq_flag = 1;
		__HAL_SPI_DISABLE(&hspi1);	
	}
}


extern void En_flow_ctrl(void)
{
	__HAL_GPIO_EXTI_CLEAR_FLAG(GPIO_PIN_0);
	__HAL_GPIO_EXTI_CLEAR_FLAG(GPIO_PIN_2);

	    //�ж���0
    HAL_NVIC_SetPriority(EXTI0_IRQn, 2, 0);
    HAL_NVIC_EnableIRQ(EXTI0_IRQn);

	//set_remoteLwip_udp_link();

	 //�ж���2
    //HAL_NVIC_SetPriority(EXTI2_IRQn, 2, 0);
    //HAL_NVIC_EnableIRQ(EXTI2_IRQn);
	index = 1;

}
void send_spi_dat(void)
{

	if(enPollint)
	{
		flow_ctrl_set(0);
		if(HAL_GPIO_ReadPin(GPIOG, GPIO_PIN_2) == GPIO_PIN_RESET && index ) {
				
				//USART3_Putbuf(&spi1_tx_buf[0],420);
				//printf("send_spi_dat  %d \r\n",HAL_GPIO_ReadPin(GPIOG, GPIO_PIN_2));
					
				Tx_end_flag= 0;
				index--;
				//delayms_Lock(1);
				spi1_tx_buf[3]++;
				if(spi1_tx_buf[3]== 0)
				{
					spi1_tx_buf[2]++;
				}
				if(HAL_SPI_Transmit_IT(&hspi1, (uint8_t *)&spi1_tx_buf[0], TS_LEN) != HAL_OK)
				{
					printf("send_spi_dat error spi master send \n");
				}

		}
	}
}

void setenPollint(uint8_t en)
{
	enPollint = en;
}

uint8_t getenPollint(void)
{
	return enPollint;
}

