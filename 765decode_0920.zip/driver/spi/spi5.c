#include "common.h"

SPI_HandleTypeDef hspi5;
#ifdef SUP_DMA_SPI5_RX
DMA_HandleTypeDef hdma_spi5_rx;
#endif

#ifdef SUP_DMA_SPI5_TX
DMA_HandleTypeDef hdma_spi5_tx;
#endif


#define SPI_BUF_SIZE 2000 //0x1000

typedef struct {
    volatile uint16_t       Write;
    volatile uint16_t       curWrite;
    volatile uint16_t       endPos;
    volatile Boolean        StartFlg;
    volatile uint16_t       Read;
    volatile Boolean        HaveData;
    volatile uint16_t       len[SPI_BUFNB];
    uint8_t                 busy;
} SPI_STREAM;

static SPI_STREAM spiStream;


__ALIGN_BEGIN uint8_t g_es_stream[SPI_BUFNB][SPI_BUF_SIZE] __ALIGN_END;



extern void Client_flow_state(uint8_t state)
{
    if(state) {
        HAL_GPIO_WritePin(GPIOG, GPIO_PIN_3, GPIO_PIN_SET);
    } else {
        HAL_GPIO_WritePin(GPIOG, GPIO_PIN_3, GPIO_PIN_RESET);
    }
}

/* SPI4 init function */
extern void MX_SPI5_Init(void)
{
    /* SPI5 parameter configuration*/
    hspi5.Instance = SPI5;
    hspi5.Init.Mode = SPI_MODE_MASTER;
    hspi5.Init.Direction = SPI_DIRECTION_2LINES;	
    hspi5.Init.DataSize = SPI_DATASIZE_8BIT;
    hspi5.Init.CLKPolarity = SPI_POLARITY_LOW;
    hspi5.Init.CLKPhase = SPI_PHASE_2EDGE;
    hspi5.Init.NSS = SPI_NSS_SOFT; 
		hspi5.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
    hspi5.Init.FirstBit = SPI_FIRSTBIT_MSB;
    hspi5.Init.TIMode = SPI_TIMODE_DISABLE;
    hspi5.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
    hspi5.Init.CRCPolynomial = 7;
    hspi5.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
    hspi5.Init.NSSPMode = SPI_NSS_PULSE_DISABLE; //SPI_NSS_PULSE_ENABLE;

    if(HAL_SPI_Init(&hspi5) != HAL_OK) {
        _Error_Handler(__FILE__, __LINE__);
    }	

    memset(&spiStream, 0x00, sizeof(spiStream));
    spiStream.endPos = SPI_BUFNB;
 
    spiStream.StartFlg = 1;
}

static uint16_t img_len=0;  //for test

extern void spi5_video_output(uint8_t *dat,uint16_t len,uint8_t lastflag)
{
	uint16_t head;
	uint16_t nextlen;
	uint8_t *p;
	
	

//Led_Test1();
	
	head = RBUF_NEXT_PT(spiStream.Write, 1, SPI_BUFNB);
	
	if(head ==spiStream.Read) { //��
		 return;
	}
		

	p = (uint8_t *)&g_es_stream[spiStream.Write] + spiStream.len[spiStream.Write];
	
	spiStream.len[spiStream.Write] += len;
		
	nextlen = spiStream.len[spiStream.Write] + TS_PACKET_SIZE;   //TS_PACKET_SIZE 188

	memcpy(p,dat,len);
	
//	printf("%d ",len);
	
	img_len += len;//add
	
	if(nextlen >= SPI_BUF_SIZE || lastflag)
	{	
		
		if(lastflag)
		{
		  spiStream.endPos = head;
		}	
		
		spiStream.Write = head; 		
		spiStream.len[spiStream.Write] = 0;    //add
		
		if(spiStream.HaveData == 0 || lastflag) {
			//Led_Test1();	
	       spiStream.HaveData = 1;
				 HAL_SPI_Transmit_DMA(&hspi5, (uint8_t *)&g_es_stream[spiStream.Read], spiStream.len[spiStream.Read]);
			
	       spiStream.Read = RBUF_NEXT_PT(spiStream.Read, 1, SPI_BUFNB);
    	}
	}

    
	
}

extern void Pollint_Spi5(void)
{
	if(spiStream.endPos == spiStream.Read)
	{
   	printf("len %d \r\n",img_len);
		img_len=0;
		
	//	Led_Test1();	
		spiStream.endPos = SPI_BUFNB;  //8
		Client_flow_state(1);
	}
	
	if(spiStream.Write == spiStream.Read) {
        spiStream.HaveData = 0;
    } else {
       HAL_SPI_Transmit_DMA(&hspi5, (uint8_t *)&g_es_stream[spiStream.Read], spiStream.len[spiStream.Read]);
        spiStream.Read = RBUF_NEXT_PT(spiStream.Read, 1, SPI_BUFNB);
    }

}
//Tx end  irq
extern void SPI5_TxCpltCallback(void)
{
	Pollint_Spi5();
}


extern void HAL_SPI_ErrorCallback(SPI_HandleTypeDef *hspi)
{
    if(hspi->Instance == SPI5) {
        //printf("spi5 error\r\n");
		USART3_Putchar(2);
    }
}



void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{

}

